<?php include "header.php";?>

	<div class="row">
		<div class="col-lg-12">
		<code><?=$json?></code>
		</div>
	</div>

<?php include "footer.php"?>