
        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Trivia.xyz 2014</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="<?=$this->config->base_url('js/jquery.js');?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?=$this->config->base_url('js/bootstrap.min.js');?>"></script>

    <!-- Script to Activate the Carousel -->
    

</body>

</html>
